<?php
$info->name = __( 'Cabriolet', 'popover' );
$info->pro = true;