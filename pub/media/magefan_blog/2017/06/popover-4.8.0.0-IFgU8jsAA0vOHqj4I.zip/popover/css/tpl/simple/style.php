<?php
$info->name = __( 'Simple', 'popover' );