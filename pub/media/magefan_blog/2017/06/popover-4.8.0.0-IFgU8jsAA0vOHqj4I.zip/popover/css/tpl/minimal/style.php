<?php
$info->name = __( 'Minimal', 'popover' );
$info->pro = true;