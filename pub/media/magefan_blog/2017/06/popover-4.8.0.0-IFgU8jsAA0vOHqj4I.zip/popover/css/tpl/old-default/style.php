<?php
$info->name = __( 'Default', 'popover' );
$info->deprecated = true;