<?php
$info->name = __( 'Default Fixed', 'popover' );
$info->deprecated = true;