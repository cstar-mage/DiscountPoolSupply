<?php
$info->name = __( 'Dark Background Fixed', 'popover' );
$info->deprecated = true;